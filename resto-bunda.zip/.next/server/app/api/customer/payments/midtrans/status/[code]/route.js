var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/customer/payments/midtrans/status/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__9b02a321._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.m(11417)
R.m(40562)
module.exports=R.m(40562).exports
