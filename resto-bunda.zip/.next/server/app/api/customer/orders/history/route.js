var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/customer/orders/history/route.js")
R.c("server/chunks/[root-of-the-server]__1bc503f7._.js")
R.c("server/chunks/node_modules_next_b97e326b._.js")
R.c("server/chunks/node_modules_@upstash_redis_45086f21._.js")
R.c("server/chunks/node_modules_zod_v4_9fe81a10._.js")
R.c("server/chunks/node_modules_586181c1._.js")
R.m("[project]/.next-internal/server/app/api/customer/orders/history/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/customer/orders/history/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/customer/orders/history/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
