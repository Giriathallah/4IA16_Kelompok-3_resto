var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/orders/route.js")
R.c("server/chunks/[root-of-the-server]__a458ff14._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/src_0b4cfa7a._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.m(88591)
R.m(99217)
module.exports=R.m(99217).exports
