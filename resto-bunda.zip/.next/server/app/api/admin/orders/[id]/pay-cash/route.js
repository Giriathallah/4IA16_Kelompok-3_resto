var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/orders/[id]/pay-cash/route.js")
R.c("server/chunks/[root-of-the-server]__53137a0f._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/src_0b4cfa7a._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.m(6760)
R.m(23671)
module.exports=R.m(23671).exports
