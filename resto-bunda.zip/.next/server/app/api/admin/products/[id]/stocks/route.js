var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/[id]/stocks/route.js")
R.c("server/chunks/[root-of-the-server]__a77774bc._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/src_0b4cfa7a._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.m(69415)
R.m(54160)
module.exports=R.m(54160).exports
