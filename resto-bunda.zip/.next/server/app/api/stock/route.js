var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stock/route.js")
R.c("server/chunks/[root-of-the-server]__165f809d._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/src_0b4cfa7a._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.m(85606)
R.m(43463)
module.exports=R.m(43463).exports
