var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/stock/route.js")
R.c("server/chunks/[root-of-the-server]__c913c769._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/src_0b4cfa7a._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.m(60647)
R.m(21167)
module.exports=R.m(21167).exports
