var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__94b6db2c._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/src_0b4cfa7a._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.m(55833)
R.m(48527)
module.exports=R.m(48527).exports
