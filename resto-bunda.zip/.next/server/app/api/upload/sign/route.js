var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/sign/route.js")
R.c("server/chunks/[root-of-the-server]__9cf9ea18._.js")
R.c("server/chunks/[root-of-the-server]__c0cfec52._.js")
R.c("server/chunks/node_modules_next_d739b5ba._.js")
R.m(54510)
R.m(93968)
module.exports=R.m(93968).exports
